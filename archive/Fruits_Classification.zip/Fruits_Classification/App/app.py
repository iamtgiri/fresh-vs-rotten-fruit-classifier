import os
import warnings

# === SUPPRESS WARNINGS ===
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

import streamlit as st
import tensorflow as tf
import numpy as np
from PIL import Image
import json

# === CONFIG ===
MODEL_PATH = "best_mobilenetv2.keras"
CLASS_NAMES_PATH = "class_names.json"
IMG_SIZE = (224, 224)

# === LOAD MODEL AND CLASS NAMES ===
@st.cache_resource
def load_model():
    return tf.keras.models.load_model(MODEL_PATH)

@st.cache_data
def load_class_names():
    with open(CLASS_NAMES_PATH, "r") as f:
        return json.load(f)

model = load_model()
class_names = load_class_names()

# === PAGE CONFIG ===
st.set_page_config(page_title="Fruit Freshness Checker", layout="centered")

# === SIDEBAR ===
with st.sidebar:
    st.markdown(
        """
        <div style='text-align: center; margin-bottom: 20px;'>
            <h2 style='margin-bottom: 0px; font-family: "Segoe UI", sans-serif;'>Fruit Freshness AI</h2>
            <p style='margin-top: 0px; font-size: 14px; color: gray; font-family: "Segoe UI", sans-serif;'>
                Built with TensorFlow & Streamlit
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown("---")
    st.markdown(
        """
        <h4 style='text-align: center;'>About the Project</h4>
        <p style='
            font-size: 13px;
            text-align: justify;
            color: white;
            line-height: 1.5;
            font-family: "Segoe UI", sans-serif;
        '>
         This project, developed by <a href='https://iamtgiri.github.io/' target='_blank' style='color: #1E90FF;'>Tanmoy Giri</a>, utilizes a deep learning model based on the <strong>MobileNetV2</strong> architecture to assess the freshness of fruits and vegetables. The model processes images at an input resolution of <strong>224×224</strong> pixels and classifies them into <strong>18 distinct categories</strong>. Trained on a dataset of over <strong>24,000 images</strong>, it aims to assist in reducing food waste and enhancing quality control across retail and supply chains.
      
        </p>
        """,
        unsafe_allow_html=True
    )
    st.markdown("<hr>", unsafe_allow_html=True)
    st.markdown("<h4 >Your feedback</h4>", unsafe_allow_html=True)

    feedback_value = st.feedback(
            options="faces",
            key="feedback_key",
        )

    sentiment = ["Very Bad", "Bad", "Okay", "Good", "Excellent"]
    response = [
        "We're sorry to hear that. We'll work on improving.",
        "Thanks for your honesty. We'll try to do better.",
        "Appreciate the feedback! We're getting there.",
        "Glad it worked well for you!",
        "Awesome! Thanks for the great feedback!"
    ]

    if feedback_value is not None:
        st.markdown(
            f"""
            <div style='text-align: center; margin-top: 10px;'>
                <p style='font-size: 16px; margin: 5px 0;'>
                    <strong>Your feedback:</strong> {sentiment[feedback_value]}
                </p>
                <p style='font-size: 14px; color: gray;'>{response[feedback_value]}</p>
            </div>
            """,
            unsafe_allow_html=True
        )





# === HEADER ===
st.markdown("<h1 style='text-align:center;'>Fruit Freshness Checker</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align:center; font-size:16px; color:gray;'>Deep learning model to classify freshness of fruits and vegetables.</p>", unsafe_allow_html=True)

# === SUPPORTED CLASSES ===
st.markdown(
    """
    <div style='
        background-color: #1a1a1a;
        padding: 16px;
        border-radius: 10px;
        border-left: 5px solid #4682B4;
        border-right: 5px solid #4682B4;
        font-family: "Segoe UI", sans-serif;
        color: #f5f5f5;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: center;
    '>
    <h4 style='text-align:center;'>Supported Produce</h4>
    <div style='
        font-family: "Segoe UI", sans-serif;
        color: #f5f5f5;
        font-size: 15px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: center;
    '>
        <span><strong>Apples</strong></span>
        <span><strong>Banana</strong></span>
        <span><strong>Cucumber</strong></span>
        <span><strong>Oranges</strong></span>
        <span><strong>Tomato</strong></span>
        <span><strong>Capsicum</strong></span>
        <span><strong>Potato</strong></span>
        <span><strong>Bitter Gourd</strong></span>
        <span><strong>Okra</strong></span>
    </div>
    </div>
    """,
    unsafe_allow_html=True
)

# === INPUT METHOD ===
st.markdown("---")
st.markdown("<h4 style='text-align:center;'>Select Input Method</h4>", unsafe_allow_html=True)

col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    option = st.radio(
        label="Select input method",
        options=["Upload Image", "Use Camera"],
        index=0,
        key="input_method_radio",
        help="Choose how you want to provide the image for analysis.",
        label_visibility="collapsed",
        horizontal=True,
        disabled=False,
        captions=["Select an image from your computer", "Capture an image from your webcam"],
        format_func=lambda x: x.upper()
    )

if option == "Upload Image":
    img_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])
elif option == "Use Camera":
    img_file = st.camera_input("Take a photo")

# === PREDICTION FUNCTION ===
def predict(image):
    image = image.resize(IMG_SIZE).convert("RGB")
    img_array = tf.keras.preprocessing.image.img_to_array(image)
    input_tensor = tf.expand_dims(img_array, axis=0)
    input_tensor = tf.keras.applications.mobilenet_v2.preprocess_input(input_tensor)
    
    preds = model.predict(input_tensor)[0]
    pred_idx = np.argmax(preds)
    raw_class = class_names[pred_idx]

    if raw_class.startswith("fresh"):
        freshness = "Fresh"
        fruit = raw_class.replace("fresh", "")
    elif raw_class.startswith("rotten"):
        freshness = "Rotten"
        fruit = raw_class.replace("rotten", "")
    else:
        freshness = "Unknown"
        fruit = raw_class

    fruit = fruit.capitalize().replace("groud", "gourd").strip()
    pred_class = f"{freshness} {fruit}"
    confidence = float(np.max(preds))
    
    return pred_class, confidence, freshness

# === SHOW RESULT ===
if img_file:
    image = Image.open(img_file)
    st.image(image, caption="Uploaded Image", use_container_width=True)

    with st.spinner("Analyzing the image using the model..."):
        pred_class, confidence, freshness = predict(image)

    # Confidence-based styling
    confidence_color = (
        "#2ecc71" if confidence > 0.85 else "#f39c12" if confidence > 0.6 else "#e74c3c"
    )
    confidence_label = (
        "High" if confidence > 0.85 else "Moderate" if confidence > 0.6 else "Low"
    )

    # Recommendation text
    recommendation = {
        "Fresh": "Suitable for consumption or sale.",
        "Rotten": "Consider discarding or composting.",
        "Unknown": "Re-scan with better lighting or resolution."
    }[freshness]

    # === Container start ===
    status_color = "#27ae60" if freshness == "Fresh" else "#c0392b"
    st.markdown(
        f"""
        <div style="
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 12px;
            padding: 24px;
            border-left: 6px solid #4682B4;
            border-right: 6px solid #4682B4;
            color: #F5F5F5;
            font-family: 'Segoe UI', sans-serif;
            margin-top: 20px;">
            <h3 style="margin-top: 0; text-align: center; color: #ffffff;">Model Prediction</h3>
            <hr>
            <div style="font-size: 20px; margin: 10px 0;">
                <strong>Prediction:</strong>
                <span style="color: #ffffff;">{pred_class}</span>
            </div>
            <div style="font-size: 18px; margin: 8px 0;">
                <strong>Status:</strong>
                <span style="
                    background-color: {status_color};
                    color: white;
                    padding: 4px 10px;
                    border-radius: 5px;
                    font-weight: bold;
                    margin-left: 6px;">
                    {freshness.upper()}
                </span>
            </div>
            <div style="font-size: 18px; margin: 8px 0;">
                <strong>Confidence:</strong>
                <span style="color: {confidence_color}; font-weight: 600;">
                    {confidence * 100:.2f}% ({confidence_label})
                </span>
            </div>
            <div style="font-size: 18px; margin: 8px 0;">
                <strong>Recommendation:</strong>
                <span style="font-weight: 600;">
                    {recommendation}
                </span>
            </div>
        """,
        unsafe_allow_html=True
    )

    # === Container end ===
    st.markdown("</div>", unsafe_allow_html=True)



# === FOOTER ===
st.markdown("<hr>", unsafe_allow_html=True)
st.markdown(
    "<p style='text-align: center; font-size: 13px; color: gray;'>"
    "This tool is for demonstration purposes only. Accuracy depends on image quality."
    "</p>",
    unsafe_allow_html=True
)



